let carrinho = [];
let total = 0;

function adicionarAoCarrinho(nome, preco) {
  carrinho.push({ nome, preco });
  total += preco;
  atualizarCarrinho();
}

function atualizarCarrinho() {
  const lista = document.getElementById("itens-carrinho");
  const totalSpan = document.getElementById("total");
  const countSpan = document.getElementById("cart-count");
  lista.innerHTML = "";
  carrinho.forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${item.nome} - €${item.preco.toFixed(2)}`;
    lista.appendChild(li);
  });
  totalSpan.textContent = total.toFixed(2);
  countSpan.textContent = carrinho.length;
}

function toggleCart() {
  document.getElementById("carrinho").classList.toggle("oculto");
}
